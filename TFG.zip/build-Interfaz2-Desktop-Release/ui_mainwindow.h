/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QPushButton *clearButton;
    QHBoxLayout *horizontalLayout_10;
    QPushButton *loadConfigButton;
    QLineEdit *lineEdit;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer;
    QLineEdit *sampleTimeEdit;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_3;
    QSpacerItem *horizontalSpacer_2;
    QLineEdit *postExecEdit;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_4;
    QSpacerItem *horizontalSpacer_3;
    QLineEdit *minPowerEdit;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_5;
    QSpacerItem *horizontalSpacer_4;
    QLineEdit *outputFIleEdit;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_6;
    QSpacerItem *horizontalSpacer_5;
    QLineEdit *subdomainEdit;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_7;
    QSpacerItem *horizontalSpacer_7;
    QLineEdit *gpuEdit;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_8;
    QSpacerItem *horizontalSpacer_10;
    QComboBox *useBox;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_9;
    QPushButton *executableButton;
    QLineEdit *executableEdit;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_10;
    QLineEdit *argumentsEdit;
    QHBoxLayout *horizontalLayout_13;
    QPushButton *applyButton;
    QPushButton *saveButton;
    QHBoxLayout *horizontalLayout_12;
    QRadioButton *powerCheck;
    QRadioButton *energyCheck;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_11;
    QPushButton *startButton;
    QHBoxLayout *horizontalLayout_11;
    QLineEdit *archiveEdit;
    QPushButton *loadArchiveButton;
    QCustomPlot *customPlot;
    QPushButton *aboutButton;
    QListView *listView;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1511, 821);
        QSizePolicy sizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMinimumSize(QSize(1511, 821));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(centralwidget->sizePolicy().hasHeightForWidth());
        centralwidget->setSizePolicy(sizePolicy1);
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setHorizontalSpacing(12);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetFixedSize);
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy2);

        verticalLayout->addWidget(label);

        clearButton = new QPushButton(centralwidget);
        clearButton->setObjectName(QString::fromUtf8("clearButton"));

        verticalLayout->addWidget(clearButton);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(12);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        loadConfigButton = new QPushButton(centralwidget);
        loadConfigButton->setObjectName(QString::fromUtf8("loadConfigButton"));

        horizontalLayout_10->addWidget(loadConfigButton);

        lineEdit = new QLineEdit(centralwidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        QSizePolicy sizePolicy3(QSizePolicy::MinimumExpanding, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(lineEdit->sizePolicy().hasHeightForWidth());
        lineEdit->setSizePolicy(sizePolicy3);
        lineEdit->setReadOnly(true);

        horizontalLayout_10->addWidget(lineEdit);


        verticalLayout->addLayout(horizontalLayout_10);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        sampleTimeEdit = new QLineEdit(centralwidget);
        sampleTimeEdit->setObjectName(QString::fromUtf8("sampleTimeEdit"));

        horizontalLayout->addWidget(sampleTimeEdit);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_2->addWidget(label_3);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        postExecEdit = new QLineEdit(centralwidget);
        postExecEdit->setObjectName(QString::fromUtf8("postExecEdit"));

        horizontalLayout_2->addWidget(postExecEdit);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_3->addWidget(label_4);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_3);

        minPowerEdit = new QLineEdit(centralwidget);
        minPowerEdit->setObjectName(QString::fromUtf8("minPowerEdit"));

        horizontalLayout_3->addWidget(minPowerEdit);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_4->addWidget(label_5);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_4);

        outputFIleEdit = new QLineEdit(centralwidget);
        outputFIleEdit->setObjectName(QString::fromUtf8("outputFIleEdit"));

        horizontalLayout_4->addWidget(outputFIleEdit);


        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_5->addWidget(label_6);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_5);

        subdomainEdit = new QLineEdit(centralwidget);
        subdomainEdit->setObjectName(QString::fromUtf8("subdomainEdit"));

        horizontalLayout_5->addWidget(subdomainEdit);


        verticalLayout->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        label_7 = new QLabel(centralwidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout_6->addWidget(label_7);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_7);

        gpuEdit = new QLineEdit(centralwidget);
        gpuEdit->setObjectName(QString::fromUtf8("gpuEdit"));

        horizontalLayout_6->addWidget(gpuEdit);


        verticalLayout->addLayout(horizontalLayout_6);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        label_8 = new QLabel(centralwidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_7->addWidget(label_8);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_10);

        useBox = new QComboBox(centralwidget);
        useBox->addItem(QString());
        useBox->addItem(QString());
        useBox->addItem(QString());
        useBox->setObjectName(QString::fromUtf8("useBox"));

        horizontalLayout_7->addWidget(useBox);


        verticalLayout->addLayout(horizontalLayout_7);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(12);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        label_9 = new QLabel(centralwidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout_8->addWidget(label_9);

        executableButton = new QPushButton(centralwidget);
        executableButton->setObjectName(QString::fromUtf8("executableButton"));

        horizontalLayout_8->addWidget(executableButton);

        executableEdit = new QLineEdit(centralwidget);
        executableEdit->setObjectName(QString::fromUtf8("executableEdit"));
        executableEdit->setReadOnly(false);

        horizontalLayout_8->addWidget(executableEdit);


        verticalLayout->addLayout(horizontalLayout_8);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(12);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        label_10 = new QLabel(centralwidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        horizontalLayout_9->addWidget(label_10);

        argumentsEdit = new QLineEdit(centralwidget);
        argumentsEdit->setObjectName(QString::fromUtf8("argumentsEdit"));

        horizontalLayout_9->addWidget(argumentsEdit);


        verticalLayout->addLayout(horizontalLayout_9);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(12);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        applyButton = new QPushButton(centralwidget);
        applyButton->setObjectName(QString::fromUtf8("applyButton"));

        horizontalLayout_13->addWidget(applyButton);

        saveButton = new QPushButton(centralwidget);
        saveButton->setObjectName(QString::fromUtf8("saveButton"));

        horizontalLayout_13->addWidget(saveButton);


        verticalLayout->addLayout(horizontalLayout_13);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(12);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        powerCheck = new QRadioButton(centralwidget);
        powerCheck->setObjectName(QString::fromUtf8("powerCheck"));
        powerCheck->setChecked(true);

        horizontalLayout_12->addWidget(powerCheck);

        energyCheck = new QRadioButton(centralwidget);
        energyCheck->setObjectName(QString::fromUtf8("energyCheck"));
        energyCheck->setChecked(false);

        horizontalLayout_12->addWidget(energyCheck);


        verticalLayout->addLayout(horizontalLayout_12);


        gridLayout->addLayout(verticalLayout, 1, 0, 2, 1);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_11 = new QLabel(centralwidget);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        QSizePolicy sizePolicy4(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(label_11->sizePolicy().hasHeightForWidth());
        label_11->setSizePolicy(sizePolicy4);

        verticalLayout_2->addWidget(label_11);

        startButton = new QPushButton(centralwidget);
        startButton->setObjectName(QString::fromUtf8("startButton"));
        sizePolicy4.setHeightForWidth(startButton->sizePolicy().hasHeightForWidth());
        startButton->setSizePolicy(sizePolicy4);

        verticalLayout_2->addWidget(startButton);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        archiveEdit = new QLineEdit(centralwidget);
        archiveEdit->setObjectName(QString::fromUtf8("archiveEdit"));
        archiveEdit->setReadOnly(true);

        horizontalLayout_11->addWidget(archiveEdit);

        loadArchiveButton = new QPushButton(centralwidget);
        loadArchiveButton->setObjectName(QString::fromUtf8("loadArchiveButton"));

        horizontalLayout_11->addWidget(loadArchiveButton);


        verticalLayout_2->addLayout(horizontalLayout_11);


        gridLayout->addLayout(verticalLayout_2, 1, 1, 1, 1);

        customPlot = new QCustomPlot(centralwidget);
        customPlot->setObjectName(QString::fromUtf8("customPlot"));
        QSizePolicy sizePolicy5(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(customPlot->sizePolicy().hasHeightForWidth());
        customPlot->setSizePolicy(sizePolicy5);

        gridLayout->addWidget(customPlot, 2, 1, 3, 1);

        aboutButton = new QPushButton(centralwidget);
        aboutButton->setObjectName(QString::fromUtf8("aboutButton"));
        QSizePolicy sizePolicy6(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy6.setHorizontalStretch(0);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(aboutButton->sizePolicy().hasHeightForWidth());
        aboutButton->setSizePolicy(sizePolicy6);
        aboutButton->setMinimumSize(QSize(0, 0));
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(28, 113, 216, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(102, 171, 255, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush2);
        QBrush brush3(QColor(65, 142, 235, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        QBrush brush4(QColor(14, 57, 108, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush4);
        QBrush brush5(QColor(19, 75, 144, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        QBrush brush6(QColor(255, 255, 255, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush6);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        QBrush brush7(QColor(141, 184, 235, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush7);
        QBrush brush8(QColor(255, 255, 220, 255));
        brush8.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush8);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        QBrush brush9(QColor(0, 0, 0, 128));
        brush9.setStyle(Qt::SolidPattern);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Active, QPalette::PlaceholderText, brush9);
#endif
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush7);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush8);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Inactive, QPalette::PlaceholderText, brush9);
#endif
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush8);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Disabled, QPalette::PlaceholderText, brush9);
#endif
        aboutButton->setPalette(palette);

        gridLayout->addWidget(aboutButton, 6, 0, 1, 1);

        listView = new QListView(centralwidget);
        listView->setObjectName(QString::fromUtf8("listView"));
        sizePolicy1.setHeightForWidth(listView->sizePolicy().hasHeightForWidth());
        listView->setSizePolicy(sizePolicy1);
        listView->setAutoScroll(false);
        listView->setDragEnabled(false);

        gridLayout->addWidget(listView, 3, 0, 2, 1);

        gridLayout->setColumnStretch(0, 3);
        gridLayout->setColumnStretch(1, 5);
        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:22pt; font-weight:600;\">CONFIGURATION</span></p></body></html>", nullptr));
        clearButton->setText(QCoreApplication::translate("MainWindow", "Clear configuration", nullptr));
        loadConfigButton->setText(QCoreApplication::translate("MainWindow", "Load config...", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "SAMPLE TIME", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "POST EXECUTION TIME", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "MINIMUN POWER", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "OUTPUT FILE", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "SUBDOMAIN", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "GPU", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "USE", nullptr));
        useBox->setItemText(0, QCoreApplication::translate("MainWindow", "CPU", nullptr));
        useBox->setItemText(1, QCoreApplication::translate("MainWindow", "GPU", nullptr));
        useBox->setItemText(2, QCoreApplication::translate("MainWindow", "CPU,GPU", nullptr));

        useBox->setCurrentText(QCoreApplication::translate("MainWindow", "CPU", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "EXECUTABLE", nullptr));
        executableButton->setText(QCoreApplication::translate("MainWindow", "Browse...", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "ARGUMENTS", nullptr));
        applyButton->setText(QCoreApplication::translate("MainWindow", "Save and apply", nullptr));
        saveButton->setText(QCoreApplication::translate("MainWindow", "Save as...", nullptr));
        powerCheck->setText(QCoreApplication::translate("MainWindow", "Power (W)", nullptr));
        energyCheck->setText(QCoreApplication::translate("MainWindow", "Energy (J)", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:22pt; font-weight:600;\">EXECUTION</span></p></body></html>", nullptr));
        startButton->setText(QCoreApplication::translate("MainWindow", "Start monitorizing", nullptr));
        loadArchiveButton->setText(QCoreApplication::translate("MainWindow", "Load archive...", nullptr));
#if QT_CONFIG(tooltip)
        aboutButton->setToolTip(QCoreApplication::translate("MainWindow", "About the application", nullptr));
#endif // QT_CONFIG(tooltip)
        aboutButton->setText(QCoreApplication::translate("MainWindow", "?", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
