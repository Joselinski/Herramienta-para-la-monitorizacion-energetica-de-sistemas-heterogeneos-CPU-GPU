/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../Interfaz2/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[23];
    char stringdata0[426];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 11), // "applyConfig"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 14), // "loadExecutable"
QT_MOC_LITERAL(4, 39, 21), // "on_saveButton_clicked"
QT_MOC_LITERAL(5, 61, 27), // "on_loadConfigButton_clicked"
QT_MOC_LITERAL(6, 89, 22), // "on_clearButton_clicked"
QT_MOC_LITERAL(7, 112, 22), // "on_startButton_clicked"
QT_MOC_LITERAL(8, 135, 21), // "on_stopButton_clicked"
QT_MOC_LITERAL(9, 157, 28), // "on_loadArchiveButton_clicked"
QT_MOC_LITERAL(10, 186, 22), // "updatePlotForSelection"
QT_MOC_LITERAL(11, 209, 16), // "realtimeDataSlot"
QT_MOC_LITERAL(12, 226, 30), // "updateListViewFromUseAndConfig"
QT_MOC_LITERAL(13, 257, 15), // "onUseBoxChanged"
QT_MOC_LITERAL(14, 273, 4), // "text"
QT_MOC_LITERAL(15, 278, 22), // "on_aboutButton_clicked"
QT_MOC_LITERAL(16, 301, 22), // "onPlotZoomOrPanChanged"
QT_MOC_LITERAL(17, 324, 17), // "onPlotDoubleClick"
QT_MOC_LITERAL(18, 342, 23), // "onCustomPlotDoubleClick"
QT_MOC_LITERAL(19, 366, 20), // "enforcePositiveYAxis"
QT_MOC_LITERAL(20, 387, 8), // "QCPRange"
QT_MOC_LITERAL(21, 396, 8), // "newRange"
QT_MOC_LITERAL(22, 405, 20) // "enforcePositiveXAxis"

    },
    "MainWindow\0applyConfig\0\0loadExecutable\0"
    "on_saveButton_clicked\0on_loadConfigButton_clicked\0"
    "on_clearButton_clicked\0on_startButton_clicked\0"
    "on_stopButton_clicked\0"
    "on_loadArchiveButton_clicked\0"
    "updatePlotForSelection\0realtimeDataSlot\0"
    "updateListViewFromUseAndConfig\0"
    "onUseBoxChanged\0text\0on_aboutButton_clicked\0"
    "onPlotZoomOrPanChanged\0onPlotDoubleClick\0"
    "onCustomPlotDoubleClick\0enforcePositiveYAxis\0"
    "QCPRange\0newRange\0enforcePositiveXAxis"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  104,    2, 0x08 /* Private */,
       3,    0,  105,    2, 0x08 /* Private */,
       4,    0,  106,    2, 0x08 /* Private */,
       5,    0,  107,    2, 0x08 /* Private */,
       6,    0,  108,    2, 0x08 /* Private */,
       7,    0,  109,    2, 0x08 /* Private */,
       8,    0,  110,    2, 0x08 /* Private */,
       9,    0,  111,    2, 0x08 /* Private */,
      10,    0,  112,    2, 0x08 /* Private */,
      11,    0,  113,    2, 0x08 /* Private */,
      12,    0,  114,    2, 0x08 /* Private */,
      13,    1,  115,    2, 0x08 /* Private */,
      15,    0,  118,    2, 0x08 /* Private */,
      16,    0,  119,    2, 0x08 /* Private */,
      17,    0,  120,    2, 0x08 /* Private */,
      18,    0,  121,    2, 0x08 /* Private */,
      19,    1,  122,    2, 0x08 /* Private */,
      22,    1,  125,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   14,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 20,   21,
    QMetaType::Void, 0x80000000 | 20,   21,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->applyConfig(); break;
        case 1: _t->loadExecutable(); break;
        case 2: _t->on_saveButton_clicked(); break;
        case 3: _t->on_loadConfigButton_clicked(); break;
        case 4: _t->on_clearButton_clicked(); break;
        case 5: _t->on_startButton_clicked(); break;
        case 6: _t->on_stopButton_clicked(); break;
        case 7: _t->on_loadArchiveButton_clicked(); break;
        case 8: _t->updatePlotForSelection(); break;
        case 9: _t->realtimeDataSlot(); break;
        case 10: _t->updateListViewFromUseAndConfig(); break;
        case 11: _t->onUseBoxChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 12: _t->on_aboutButton_clicked(); break;
        case 13: _t->onPlotZoomOrPanChanged(); break;
        case 14: _t->onPlotDoubleClick(); break;
        case 15: _t->onCustomPlotDoubleClick(); break;
        case 16: _t->enforcePositiveYAxis((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 17: _t->enforcePositiveXAxis((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 18;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
